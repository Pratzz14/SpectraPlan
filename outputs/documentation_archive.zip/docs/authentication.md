# Authentication and Leads

## Supabase setup

In Authentication → Sign In / Providers, enable Email and allow new users to sign up. For the initial email/password flow without SMTP, disable Confirm email. Signup then returns a session immediately. Emails are unverified in this configuration. Password reset is not offered by this version because customer email delivery is not configured.

If Confirm email remains enabled, the app explains that confirmation is required instead of pretending signup has logged the customer in. Supabase's default sender supports organization team addresses; public confirmation/reset delivery requires custom SMTP. See [password authentication](https://supabase.com/docs/guides/auth/passwords) and [SMTP configuration](https://supabase.com/docs/guides/auth/auth-smtp).

Copy the Project URL and publishable key from the project's Connect dialog or Settings → API Keys. Copy an administrator's UUID from Authentication → Users. The administrator must have an email/password account; a Supabase dashboard organization role does not confer an application role.

Backend `.env`:

```dotenv
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_example
ADMIN_USER_IDS=administrator-user-uuid
```

Create `frontend/.env.local` from `frontend/.env.example`:

```dotenv
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_example
```

Only the URL and publishable key belong in browser configuration. Never use a secret/service-role key or model credentials there. No secret key, database password, tables, Storage buckets, or JWKS configuration is needed. The backend checks each access token against Supabase's `/auth/v1/user` endpoint. Missing configuration and upstream failures deny access; there is no anonymous development bypass.

Separate multiple admin UUIDs with commas in `ADMIN_USER_IDS`. Restart the backend when changing the allowlist. Restart Vite or rebuild after changing frontend environment. Local environment files are ignored by Git. Roles come exclusively from the backend allowlist, never editable user metadata.

## Application behavior

- Both roles use the same Sign in / Create account page. Supabase stores and validates passwords; SpectraPlan never stores them.
- Customers see Assessment only. Enquiry ownership is fixed at creation from the authenticated identity, with an email snapshot. Admins may continue any enquiry without changing its customer attribution.
- Admins retain Assessment, Search sources, Extracted knowledge (originals, previews and uploads), Leads, and Workspace. Old `#history` bookmarks redirect to `#leads`.
- Leads retains analysis rounds, queries, answers, results, traces and exports. Email filtering is a trimmed, case-insensitive literal substring match applied before pagination. A new enquiry creates a new lead; clarification rounds stay on the same lead.
- Original files, images, ingestion, corpus artifacts, general evidence/search APIs, workspace status and raw traces are admin-only. Downloads and previews use authenticated fetches and temporary blob URLs, never tokens in URLs.
- Logout, expiry and account changes remove the previous workspace. Restored sessions pass `/api/me` before private pages mount.

## API changes

Every `/api/*` route requires `Authorization: Bearer <token>` and returns `Cache-Control: no-store`. `GET /api/me` returns `{id, email, role}`. Invalid/missing sessions return 401; unavailable auth returns 503; admin-only operations return 403; other customers' and unowned legacy records return 404.

`GET /api/enquiries?email=<substring>&limit=50&offset=0` is admin-only. Summary/detail types add nullable `owner_user_id` and `customer_email`. `GET /api/enquiries/{id}` allows the owner or admin. `GET /api/assess/{run_id}` restores an authorized result, input, answers and round references without event payloads or provider traces. Full `/explainability` and `report.pdf?audience=trace` remain admin-only; ordinary assessment PDFs allow the owner or admin.

Assessment POST rejects forged identity fields via the existing strict request schema and checks ownership before model work when continuing an enquiry. Scientific behavior and limitations are unchanged.

## Migration and deployment

SQLite adds ownership/email columns and an ownership index without deleting runs or events. Existing records retain null identity and appear as “Legacy — email unavailable” for admins; customers cannot claim them. Before rollout, back up SQLite using its backup API or stop the server and copy the database with any WAL files.

Keep one backend worker and persistent SQLite/source/index storage. Serve the frontend and `/api` from one HTTPS origin in production. Vite proxies `/api` locally. Supabase Auth must be reachable from browser and backend. Hosting, distributed storage, sales stages, outbound lead emails and public-launch abuse controls are outside this change.

## Verification

Run backend pytest, frontend tests, lint and production build as documented in README. Domain tests explicitly inject an admin identity via `tests/auth_helpers.py`; authorization tests instantiate the production app directly with mocked Supabase responses. All backend tests prohibit external HTTP. Automated checks require no live model calls or real customer signup.

API-based evaluation and `backend.cli.smoke_assessment --api` also require a current `SUPABASE_ACCESS_TOKEN` in the process environment (an admin token for evaluation traces). Tokens are sent only as Authorization headers and excluded from saved configuration. Domain tests inject identity explicitly; the production app has no bypass. Direct Python pipeline diagnostics do not use the HTTP authentication boundary.
