# Workspace workflow and cleanup report

Date: 2026-11-03. Approved cleanup completed. Removed 44,808 files totaling 6,106,223,241 logical bytes (5.69 GiB), including the earlier narrow cache/build cleanup. Installed dependencies were preserved. See `cleanup_inventory.json` for exact paths, counts and logical byte sizes.

## Interactive assessment

```mermaid
flowchart LR
  U[Customer enquiry / clarification] --> UI[React assessment workspace]
  UI --> API[FastAPI /api/assess]
  API --> E[Extract structured case facts]
  E --> R[Context-aware hybrid retrieval]
  K[(Active technical corpus)] --> R
  R --> S[Provider synthesis]
  S --> V[Validate facts and evidence references]
  V --> O[Assessment results and evidence drawer]
  API --> H[(Local SQLite history / traces)]
  H --> X[Reopen enquiry / JSON / PDF exports]
```

| Section | Owning files |
|---|---|
| Application entry and navigation | `frontend/src/main.tsx`, `frontend/src/App.tsx` |
| Customer input and assessment view | `frontend/src/components/AssessmentPage.tsx`, `CustomerInput.tsx`, `AssessmentResults.tsx`, `ActionBar.tsx` |
| Client API and presentation helpers | `frontend/src/api.ts`, `assessment.ts`, `knowledge.ts`, `workspace.css`, `styles.css` |
| HTTP routes and request handling | `backend/main.py`, `backend/models.py`, `backend/config.py`, `backend/health.py` |
| Extraction and synthesis | `backend/agent.py`, `backend/gemini_extraction.py`, `backend/prompts/assessment_synthesis.txt` |
| Provider routing, retries and availability | `backend/provider_routing.py`, `provider.py`, `gemini_provider.py`, `provider_setup.py` |
| Context-aware evidence selection | `backend/retrieval.py`, `retrieval_models.py`, `evidence.py` |
| Reference and assessment validation | `backend/validation.py`, `backend/models.py`, validation helpers in `backend/agent.py` |
| History, provenance and exports | `backend/explainability.py`, `history_pdf.py`, `report_template.html`, `frontend/src/components/HistoryPage.tsx`, `EvidenceDrawer.tsx` |

Provider selection is configurable; automatic routing can fall back across configured providers. The workflow diagram describes application control flow, not a guarantee that a generated recommendation is scientifically adequate.

## Knowledge preparation and manual search

```mermaid
flowchart TD
  A[Original PDFs / workbook / source notes] --> I[Ingest: render, extract, verify]
  I --> V[Validate provenance and retrieval eligibility]
  V --> B[Build BM25 and local BGE / Qdrant indexes]
  B --> P[Publish immutable corpus generation]
  P --> C[knowledge/current.json]
  P --> Q[Inspection report and source assets]
  W[Authorized S06 website crawl] --> WP[Separate website snapshot and indexes]
  WP --> WC[knowledge/web/current.json]
  C --> MS[Manual search: BM25 / Qdrant / hybrid / compare]
  WC --> MS
  MS --> SW[Search workspace and JSON export]
```

| Section | Owning files and storage |
|---|---|
| Original inputs | `knowledge/original_sources/`, `knowledge/source_manifest.json` |
| Extraction, verification and publication | `backend/ingest.py`, `knowledge_models.py`, `knowledge_store.py`, `backend/prompts/knowledge_extract.txt`, `knowledge_verify.txt` |
| Inspection report | `backend/knowledge_report.py`, `frontend/src/ExtractedKnowledge.tsx` |
| Technical evidence | `knowledge/current.json` → `knowledge/versions/corpus-4aac882441587796afe5/` |
| Website crawl and provenance | `backend/web_ingest.py`, `knowledge/web/current.json` → `knowledge/web/versions/web-a7d9d24faab7300545eb/` |
| Index creation and manual search | `backend/retrieval.py`, `backend/search_service.py`, `frontend/src/SearchWorkbench.tsx` |
| Local embedding model | `outputs/embedding_models/` |
| Restore without extraction-model calls | `scripts/restore_corpus.py` |

Website context is a separate searchable dataset; it is not default technical assessment evidence. Preserve active version directories, their assets and indexes. Root-level knowledge JSON files are convenience exports, not proof that they are safe to remove: tools and tests may use them.

## Evaluation and verification

```mermaid
flowchart LR
  F[Organizer final scenarios] --> EI[evaluation/final.json]
  EI --> ER[Evaluation runner]
  ER --> RUN[Immutable batch: requests, answers, evidence, traces, source snapshot]
  RUN --> CHECK[Verify complete batch]
  CHECK --> PUB[Publish H01-H06 and run_manifest.json]
  PUB --> AUDIT[Portable submission verification]
```

| Section | Files |
|---|---|
| Development and final inputs | `evaluation/development.json`, `evaluation/final.json`, `customer_scenarios_for_final_evaluation.txt` |
| Runner and publication | `evaluation/run_evaluation.py` |
| Canonical final outputs | `outputs/H01.json` through `outputs/H06.json`, `outputs/run_manifest.json` |
| Published source batch | `outputs/runs/20261018T143757Z_4c14fccd1a3d4eadb672c14de91c142e/` |
| Portable verifier | `scripts/verify_submission.py` |
| Backend regression coverage | `tests/test_*.py`, `tests/conftest.py`, `tests/corpus_fixture.py` |
| Frontend tests and build | `frontend/tests/*.test.mjs`, `frontend/package.json`, `frontend/vite.config.ts`, `frontend/tsconfig.json` |
| Scientific and implementation limitations | `docs/scenario_content_review.md`, `retrieval_implementation_review.md`, `acceptance_review.md` |

`python scripts/verify_submission.py --portable` passed before and after cleanup, with no errors. The final receipt is `outputs/cleanup_verification.json`. All approved removal paths were confirmed absent. Git status showed no tracked deletions. This checks artifact consistency; it does not establish scientific correctness. No application code has been changed and no live provider calls were made for this report.

## Cleanup decisions

Removed: old `tmp/` test/install workspaces; failed or completed unpublished staging directories; `outputs/test-tmp-*`; ignored historical `outputs/development/` runs; generated frontend and presentation build output; `.pytest_cache/`; 54 optional `outputs/runs/**/*.trace.pdf` derivatives. Each target was resolved inside the workspace and checked for tracked files before deletion. Portable final trace JSON and canonical final batch files were preserved.

Preserve `.git`, `.codex`, `.env`, original inputs, `.venv`, frontend and presentation dependencies, source code, tests, lockfiles, documentation, presentation source/deck, active knowledge indexes, embedding models, ingestion caches, and application history. Preserve tracked older run and review artifacts because current reviews reference them and they document known failures. An old timestamp alone does not make a file disposable.

The original bulk deletion command was rejected without changes. After the user approved the revised inventory, all remaining inventoried paths were deleted successfully. `.pytest_cache/` (5 files, 30,703 bytes) and `frontend/dist/` (3 files, 342,593 bytes) had already been removed in the earlier narrow cleanup. Directory logical sizes do not necessarily equal disk space recovered, particularly with OneDrive or sparse files. No commit or push was performed.
